namespace SaludPay.Models;

public class Pago {
    public int Id { get; set; }
    public string CedulaUsuario { get; set; } // Aquí conectas con la cédula del JWT
    public decimal Monto { get; set; }
    public string Estado { get; set; }
}