namespace SaludPay.Services;

public interface IPagoService {
    string Procesar(string cedula, decimal monto);
}

public class PagoService : IPagoService {
    public string Procesar(string cedula, decimal monto) {
        // Aquí iría tu lógica de negocio (base de datos, llamada a pasarela, etc.)
        return $"Pago de ${monto} procesado para usuario {cedula}";
    }
}