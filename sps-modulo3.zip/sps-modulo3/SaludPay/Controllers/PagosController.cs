using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SaludPay.Services;
using System.Security.Claims;

[Route("api/[controller]")]
[ApiController]
public class PagosController : ControllerBase {
    private readonly IPagoService _pagoService;

    public PagosController(IPagoService pagoService) {
        _pagoService = pagoService;
    }

    [Authorize]
    [HttpPost("procesar")]
    public IActionResult Procesar([FromBody] decimal monto) {
        // Obtenemos la cédula del token JWT automáticamente
        var cedula = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        
        var resultado = _pagoService.Procesar(cedula, monto);
        return Ok(new { Mensaje = resultado });
    }
}