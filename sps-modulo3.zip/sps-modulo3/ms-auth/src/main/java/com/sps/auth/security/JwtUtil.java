package com.sps.auth.security;

import com.sps.auth.entity.UsuarioSPS;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Component
public class JwtUtil {
    @Value("${app.jwt.secret}")
    private String secret;

    private static final long EXPIRY_MS = 7200_000L;

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public String generarToken(UsuarioSPS usuario) {
        return Jwts.builder()
            .subject(usuario.getCedula())
            .claim("cedula", usuario.getCedula())
            .claim("nombre", usuario.getNombre() + " " + usuario.getApellido())
            .claim("correo", usuario.getCorreo())
            .claim("rol", usuario.getRol().name())
            .issuedAt(new Date())
            .expiration(new Date(System.currentTimeMillis() + EXPIRY_MS))
            .signWith(getSigningKey())
            .compact();
    }

    public Claims validarToken(String token) {
        return Jwts.parser()
            .verifyWith(getSigningKey())
            .build()
            .parseSignedClaims(token)
            .getPayload();
    }
}