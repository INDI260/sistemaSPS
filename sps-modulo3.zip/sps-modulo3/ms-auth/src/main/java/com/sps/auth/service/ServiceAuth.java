package com.sps.auth.service;

import com.sps.auth.dto.AuthDTOs.*;
import com.sps.auth.entity.RolUsuario;
import com.sps.auth.entity.UsuarioSPS;
import com.sps.auth.repository.RepoAuth;
import com.sps.auth.security.JwtUtil;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@Transactional
public class ServiceAuth {
    
    @Autowired private RepoAuth repoAuth;
    @Autowired private JwtUtil jwtUtil;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(12);

    public LoginResponseDTO login(String cedula, String contrasena) {
        UsuarioSPS usuario = repoAuth.findByCedula(cedula)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciales inválidas"));
        
        if (!encoder.matches(contrasena, usuario.getContrasena()) || !usuario.getActivo()) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Credenciales inválidas o usuario inactivo");
        }
        
        String token = jwtUtil.generarToken(usuario);
        return new LoginResponseDTO(token, usuario.getCedula(), usuario.getNombre() + " " + usuario.getApellido(), usuario.getRol().name());
    }

    public UsuarioDTO registrar(RegistroRequestDTO dto) {
        if (repoAuth.existsByCedula(dto.cedula())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cédula ya registrada");
        }
        
        UsuarioSPS u = new UsuarioSPS();
        u.setCedula(dto.cedula());
        u.setNombre(dto.nombre());
        u.setApellido(dto.apellido());
        u.setCorreo(dto.correo());
        u.setContrasena(encoder.encode(dto.contrasena()));
        u.setRol(RolUsuario.CLIENTE);
        
        repoAuth.save(u);
        return new UsuarioDTO(u.getCedula(), u.getNombre(), u.getApellido(), u.getCorreo(), u.getRol().name());
    }

    public UsuarioDTO validarToken(String token) {
        Claims claims = jwtUtil.validarToken(token);
        return new UsuarioDTO(
            claims.get("cedula", String.class),
            claims.get("nombre", String.class).split(" ")[0],
            "",
            claims.get("correo", String.class),
            claims.get("rol", String.class)
        );
    }

    public UsuarioDTO obtenerPorCedula(String cedula) {
        UsuarioSPS u = repoAuth.findByCedula(cedula)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Usuario no encontrado"));
        return new UsuarioDTO(u.getCedula(), u.getNombre(), u.getApellido(), u.getCorreo(), u.getRol().name());
    }
}